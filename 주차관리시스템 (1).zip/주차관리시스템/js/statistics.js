// 인증 체크
function checkAuth() {
    const currentUser = sessionStorage.getItem('currentUser');
    const userType = sessionStorage.getItem('userType');

    if (!currentUser || userType !== 'admin') {
        alert('관리자 권한이 필요합니다.');
        window.location.href = 'index.html';
        return null;
    }

    return JSON.parse(currentUser);
}

// 연도 옵션 생성
function populateYears() {
    const currentYear = new Date().getFullYear();
    const select = document.getElementById('filterYear');
    
    select.innerHTML = '<option value="">선택하세요</option>';
    for (let year = currentYear - 2; year <= currentYear + 2; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year + '년';
        select.appendChild(option);
    }
    select.value = currentYear;
}

// 월별 일일 결제 추적 (미당첨 SUV)
function loadMonthlyTracking() {
    const year = document.getElementById('filterYear').value;
    const quarter = document.getElementById('filterQuarter').value;
    const month = document.getElementById('trackingMonth').value;
    
    if (!year || !month) return;
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    
    // 미당첨 SUV 신청만 필터링
    const suvApplications = applications.filter(app => 
        app.year == year &&
        app.parkingType === '미당첨 SUV' &&
        app.status === '승인'
    );
    
    // 해당 월의 일수 계산
    const daysInMonth = new Date(year, month, 0).getDate();
    const grid = document.getElementById('monthlyGrid');
    grid.innerHTML = '';
    
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const dayApplications = suvApplications.filter(app => {
            const appDate = new Date(app.createdAt);
            return appDate.getDate() === day;
        });
        
        const cell = document.createElement('div');
        cell.className = 'day-cell';
        if (dayApplications.length > 0) {
            cell.classList.add('approved');
        }
        
        cell.innerHTML = `
            <div class="date">${day}일</div>
            <div class="count">${dayApplications.length}건</div>
        `;
        
        grid.appendChild(cell);
    }
}

// 통계 로드
function loadStatistics() {
    const year = document.getElementById('filterYear').value;
    const quarter = document.getElementById('filterQuarter').value;
    const type = document.getElementById('filterType').value;
    
    if (!year || !quarter) {
        clearStatistics();
        return;
    }
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    
    // 필터링
    let filtered = applications.filter(app => 
        app.year == year && app.quarter == quarter
    );
    
    if (type) {
        filtered = filtered.filter(app => app.parkingType === type);
    }
    
    // 전체 통계
    updateOverallStats(filtered);
    
    // 유형별 통계
    updateTypeStats(filtered);
    
    // 부서별 통계
    updateDepartmentStats(filtered, employees);
    
    // 상세 내역
    updateDetails(filtered, employees);
    
    // 미당첨 SUV 월별 추적 표시
    if (type === '미당첨 SUV' || !type) {
        document.getElementById('monthlyTrackingSection').style.display = 'block';
        populateMonths(quarter);
    } else {
        document.getElementById('monthlyTrackingSection').style.display = 'none';
    }
}

function clearStatistics() {
    document.getElementById('totalApplications').textContent = '0';
    document.getElementById('approvedApplications').textContent = '0';
    document.getElementById('pendingApplications').textContent = '0';
    document.getElementById('rejectedApplications').textContent = '0';
    document.getElementById('approvalRate').textContent = '0%';
    document.getElementById('typeStatsBody').innerHTML = '';
    document.getElementById('deptStatsBody').innerHTML = '';
    document.getElementById('detailsBody').innerHTML = '';
    document.getElementById('monthlyTrackingSection').style.display = 'none';
}

function updateOverallStats(applications) {
    const total = applications.length;
    const approved = applications.filter(app => app.status === '승인').length;
    const pending = applications.filter(app => app.status === '대기중').length;
    const rejected = applications.filter(app => app.status === '반려').length;
    const rate = total > 0 ? ((approved / total) * 100).toFixed(1) : 0;
    
    document.getElementById('totalApplications').textContent = total;
    document.getElementById('approvedApplications').textContent = approved;
    document.getElementById('pendingApplications').textContent = pending;
    document.getElementById('rejectedApplications').textContent = rejected;
    document.getElementById('approvalRate').textContent = rate + '%';
}

function updateTypeStats(applications) {
    const types = ['선착순 일일권', '월정기권', '미당첨 SUV'];
    const tbody = document.getElementById('typeStatsBody');
    tbody.innerHTML = '';
    
    types.forEach(type => {
        const typeApps = applications.filter(app => app.parkingType === type);
        const total = typeApps.length;
        const approved = typeApps.filter(app => app.status === '승인').length;
        const pending = typeApps.filter(app => app.status === '대기중').length;
        const rejected = typeApps.filter(app => app.status === '반려').length;
        const rate = total > 0 ? ((approved / total) * 100).toFixed(1) : 0;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${type}</td>
            <td>${total}</td>
            <td>${approved}</td>
            <td>${pending}</td>
            <td>${rejected}</td>
            <td>${rate}%</td>
        `;
        tbody.appendChild(row);
    });
}

function updateDepartmentStats(applications, employees) {
    const deptMap = {};
    
    applications.forEach(app => {
        const employee = employees.find(e => e.id === app.employeeId);
        const dept = employee?.department || '미지정';
        
        if (!deptMap[dept]) {
            deptMap[dept] = { total: 0, approved: 0, pending: 0, rejected: 0 };
        }
        
        deptMap[dept].total++;
        if (app.status === '승인') deptMap[dept].approved++;
        if (app.status === '대기중') deptMap[dept].pending++;
        if (app.status === '반려') deptMap[dept].rejected++;
    });
    
    const tbody = document.getElementById('deptStatsBody');
    tbody.innerHTML = '';
    
    Object.keys(deptMap).sort().forEach(dept => {
        const stats = deptMap[dept];
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${dept}</td>
            <td>${stats.total}</td>
            <td>${stats.approved}</td>
            <td>${stats.pending}</td>
            <td>${stats.rejected}</td>
        `;
        tbody.appendChild(row);
    });
}

function updateDetails(applications, employees) {
    const tbody = document.getElementById('detailsBody');
    tbody.innerHTML = '';
    
    applications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).forEach(app => {
        const employee = employees.find(e => e.id === app.employeeId);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(app.createdAt).toLocaleDateString()}</td>
            <td>${employee?.name || '-'}</td>
            <td>${employee?.department || '-'}</td>
            <td>${app.parkingType}</td>
            <td>${app.carNumber}</td>
            <td><span class="status-badge status-${getStatusClass(app.status)}">${app.status}</span></td>
        `;
        tbody.appendChild(row);
    });
}

function getStatusClass(status) {
    if (status === '대기중') return 'pending';
    if (status === '승인') return 'approved';
    if (status === '반려') return 'rejected';
    return 'pending';
}

function populateMonths(quarter) {
    const select = document.getElementById('trackingMonth');
    select.innerHTML = '<option value="">월 선택</option>';
    
    const startMonth = (quarter - 1) * 3 + 1;
    const endMonth = startMonth + 2;
    
    for (let month = startMonth; month <= endMonth; month++) {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = month + '월';
        select.appendChild(option);
    }
}

// CSV 다운로드
function exportStatisticsCSV() {
    const year = document.getElementById('filterYear').value;
    const quarter = document.getElementById('filterQuarter').value;
    
    if (!year || !quarter) {
        alert('연도와 분기를 선택해주세요.');
        return;
    }
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    
    const filtered = applications.filter(app => 
        app.year == year && app.quarter == quarter
    );
    
    let csv = '신청일,직원명,부서,유형,차량번호,상태\n';
    
    filtered.forEach(app => {
        const employee = employees.find(e => e.id === app.employeeId);
        csv += `${new Date(app.createdAt).toLocaleDateString()},${employee?.name || '-'},${employee?.department || '-'},${app.parkingType},${app.carNumber},${app.status}\n`;
    });
    
    downloadCSV(csv, `statistics_${year}_Q${quarter}.csv`);
}

function downloadCSV(csv, filename) {
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// 초기화
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = checkAuth();
    if (currentUser) {
        populateYears();
        
        // 현재 분기 자동 선택
        const currentMonth = new Date().getMonth() + 1;
        const currentQuarter = Math.ceil(currentMonth / 3);
        document.getElementById('filterQuarter').value = currentQuarter;
        
        loadStatistics();
    }
});