// 인증 체크
function checkAuth() {
    const currentUser = sessionStorage.getItem('currentUser');
    const userType = sessionStorage.getItem('userType');

    if (!currentUser || userType !== 'admin') {
        alert('관리자 권한이 필요합니다.');
        window.location.href = 'index.html';
        return null;
    }

    return JSON.parse(currentUser);
}

// 로그아웃
function logout() {
    sessionStorage.clear();
    window.location.href = 'index.html';
}

// 탭 전환
function switchTab(tabName) {
    // 모든 탭과 컨텐츠 비활성화
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    // 선택된 탭 활성화
    event.target.classList.add('active');
    document.getElementById(tabName).classList.add('active');

    // 해당 탭의 데이터 로드
    if (tabName === 'applications') loadApplications();
    if (tabName === 'employees') loadEmployees();
    if (tabName === 'announcements') loadAnnouncements();
    if (tabName === 'statistics') loadStatistics();
}

// 연도 옵션 생성
function populateYears() {
    const currentYear = new Date().getFullYear();
    const yearSelects = ['filterYear', 'statsYear'];
    
    yearSelects.forEach(selectId => {
        const select = document.getElementById(selectId);
        if (select) {
            for (let year = currentYear - 2; year <= currentYear + 2; year++) {
                const option = document.createElement('option');
                option.value = year;
                option.textContent = year + '년';
                select.appendChild(option);
            }
            select.value = currentYear;
        }
    });
}

// 주차 신청 관리
function loadApplications() {
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    const tbody = document.getElementById('applicationsBody');
    
    tbody.innerHTML = '';
    
    const filtered = filterApplicationsData(applications, employees);
    
    filtered.forEach(app => {
        const employee = employees.find(e => e.id === app.employeeId);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(app.createdAt).toLocaleDateString()}</td>
            <td>${employee?.name || '-'}</td>
            <td>${employee?.department || '-'}</td>
            <td>${app.year}</td>
            <td>${app.quarter}분기</td>
            <td>${app.parkingType}</td>
            <td>${app.carNumber}</td>
            <td><span class="status-badge status-${getStatusClass(app.status)}">${app.status}</span></td>
            <td>
                ${app.status === '대기중' ? `
                    <button class="btn btn-success btn-small" onclick="approveApplication('${app.id}')">승인</button>
                    <button class="btn btn-danger btn-small" onclick="rejectApplication('${app.id}')">반려</button>
                ` : '-'}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function filterApplicationsData(applications, employees) {
    const year = document.getElementById('filterYear').value;
    const quarter = document.getElementById('filterQuarter').value;
    const type = document.getElementById('filterType').value;
    const status = document.getElementById('filterStatus').value;
    const searchName = document.getElementById('searchEmployee').value.toLowerCase();
    
    return applications.filter(app => {
        const employee = employees.find(e => e.id === app.employeeId);
        
        if (year && app.year != year) return false;
        if (quarter && app.quarter != quarter) return false;
        if (type && app.parkingType !== type) return false;
        if (status && app.status !== status) return false;
        if (searchName && employee && !employee.name.toLowerCase().includes(searchName)) return false;
        
        return true;
    }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function filterApplications() {
    loadApplications();
}

function getStatusClass(status) {
    if (status === '대기중') return 'pending';
    if (status === '승인') return 'approved';
    if (status === '반려') return 'rejected';
    return 'pending';
}

function approveApplication(id) {
    if (!confirm('신청을 승인하시겠습니까?')) return;
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const app = applications.find(a => a.id === id);
    
    if (app) {
        app.status = '승인';
        app.approvedAt = new Date().toISOString();
        localStorage.setItem('parkingApplications', JSON.stringify(applications));
        loadApplications();
        alert('승인되었습니다.');
    }
}

function rejectApplication(id) {
    if (!confirm('신청을 반려하시겠습니까?')) return;
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const app = applications.find(a => a.id === id);
    
    if (app) {
        app.status = '반려';
        app.rejectedAt = new Date().toISOString();
        localStorage.setItem('parkingApplications', JSON.stringify(applications));
        loadApplications();
        alert('반려되었습니다.');
    }
}

function quickApprove() {
    if (!confirm('대기중인 모든 신청을 승인하시겠습니까?')) return;
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    let approvedCount = 0;
    
    applications.forEach(app => {
        if (app.status === '대기중') {
            app.status = '승인';
            app.approvedAt = new Date().toISOString();
            approvedCount++;
        }
    });
    
    localStorage.setItem('parkingApplications', JSON.stringify(applications));
    loadApplications();
    alert(`${approvedCount}건이 승인되었습니다.`);
}

function exportApplicationsCSV() {
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    
    let csv = '신청일,직원명,부서,연도,분기,유형,차량번호,상태\n';
    
    applications.forEach(app => {
        const employee = employees.find(e => e.id === app.employeeId);
        csv += `${new Date(app.createdAt).toLocaleDateString()},${employee?.name || '-'},${employee?.department || '-'},${app.year},${app.quarter}분기,${app.parkingType},${app.carNumber},${app.status}\n`;
    });
    
    downloadCSV(csv, 'parking_applications.csv');
}

// 직원 관리
function loadEmployees() {
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    const tbody = document.getElementById('employeesBody');
    
    tbody.innerHTML = '';
    
    employees.forEach(emp => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${emp.id}</td>
            <td>${emp.name}</td>
            <td>${emp.department}</td>
            <td>${emp.isAdmin ? '관리자' : '직원'}</td>
            <td>
                ${!emp.isAdmin ? `<button class="btn btn-danger btn-small" onclick="deleteEmployee('${emp.id}')">삭제</button>` : '-'}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function showAddEmployeeModal() {
    document.getElementById('employeeModal').classList.add('show');
    document.getElementById('employeeForm').reset();
}

function closeEmployeeModal() {
    document.getElementById('employeeModal').classList.remove('show');
}

document.getElementById('employeeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    
    const newEmployee = {
        id: document.getElementById('empId').value,
        password: document.getElementById('empPassword').value,
        name: document.getElementById('empName').value,
        department: document.getElementById('empDepartment').value,
        isAdmin: false
    };
    
    // 중복 체크
    if (employees.find(e => e.id === newEmployee.id)) {
        alert('이미 존재하는 아이디입니다.');
        return;
    }
    
    employees.push(newEmployee);
    localStorage.setItem('employees', JSON.stringify(employees));
    
    closeEmployeeModal();
    loadEmployees();
    alert('직원이 추가되었습니다.');
});

function deleteEmployee(id) {
    if (!confirm('직원을 삭제하시겠습니까?')) return;
    
    const employees = JSON.parse(localStorage.getItem('employees') || '[]');
    const filtered = employees.filter(e => e.id !== id);
    
    localStorage.setItem('employees', JSON.stringify(filtered));
    loadEmployees();
    alert('삭제되었습니다.');
}

function handleExcelUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
            
            const employees = JSON.parse(localStorage.getItem('employees') || '[]');
            let addedCount = 0;
            
            // 첫 행은 헤더로 간주하고 건너뛰기
            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                if (row.length < 4) continue;
                
                const [id, password, name, department] = row;
                
                // 중복 체크
                if (employees.find(e => e.id === id)) continue;
                
                employees.push({
                    id: id.toString(),
                    password: password.toString(),
                    name: name.toString(),
                    department: department.toString(),
                    isAdmin: false
                });
                addedCount++;
            }
            
            localStorage.setItem('employees', JSON.stringify(employees));
            loadEmployees();
            alert(`${addedCount}명의 직원이 추가되었습니다.`);
            
            // 파일 입력 초기화
            event.target.value = '';
        } catch (error) {
            alert('Excel 파일 처리 중 오류가 발생했습니다.');
            console.error(error);
        }
    };
    reader.readAsArrayBuffer(file);
}

// 공지사항 관리
function loadAnnouncements() {
    const announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
    const tbody = document.getElementById('announcementsBody');
    
    tbody.innerHTML = '';
    
    announcements.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).forEach(ann => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${ann.title}</td>
            <td>${new Date(ann.createdAt).toLocaleDateString()}</td>
            <td>${ann.author}</td>
            <td>
                <button class="btn btn-danger btn-small" onclick="deleteAnnouncement('${ann.id}')">삭제</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function showAddAnnouncementModal() {
    document.getElementById('announcementModal').classList.add('show');
    document.getElementById('announcementForm').reset();
}

function closeAnnouncementModal() {
    document.getElementById('announcementModal').classList.remove('show');
}

document.getElementById('announcementForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    const announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
    
    const newAnnouncement = {
        id: Date.now().toString(),
        title: document.getElementById('annTitle').value,
        content: document.getElementById('annContent').value,
        author: currentUser.name,
        createdAt: new Date().toISOString()
    };
    
    announcements.push(newAnnouncement);
    localStorage.setItem('announcements', JSON.stringify(announcements));
    
    closeAnnouncementModal();
    loadAnnouncements();
    alert('공지사항이 등록되었습니다.');
});

function deleteAnnouncement(id) {
    if (!confirm('공지사항을 삭제하시겠습니까?')) return;
    
    const announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
    const filtered = announcements.filter(a => a.id !== id);
    
    localStorage.setItem('announcements', JSON.stringify(filtered));
    loadAnnouncements();
    alert('삭제되었습니다.');
}

// 통계
function loadStatistics() {
    const year = document.getElementById('statsYear').value;
    const quarter = document.getElementById('statsQuarter').value;
    
    if (!year || !quarter) {
        document.getElementById('totalApplications').textContent = '0';
        document.getElementById('approvedApplications').textContent = '0';
        document.getElementById('pendingApplications').textContent = '0';
        document.getElementById('rejectedApplications').textContent = '0';
        return;
    }
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    
    const filtered = applications.filter(app => 
        app.year == year && app.quarter == quarter
    );
    
    const approved = filtered.filter(app => app.status === '승인').length;
    const pending = filtered.filter(app => app.status === '대기중').length;
    const rejected = filtered.filter(app => app.status === '반려').length;
    
    document.getElementById('totalApplications').textContent = filtered.length;
    document.getElementById('approvedApplications').textContent = approved;
    document.getElementById('pendingApplications').textContent = pending;
    document.getElementById('rejectedApplications').textContent = rejected;
}

// CSV 다운로드
function downloadCSV(csv, filename) {
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// 초기화
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = checkAuth();
    if (currentUser) {
        document.getElementById('userName').textContent = currentUser.name + ' 님';
        populateYears();
        loadApplications();
    }
});