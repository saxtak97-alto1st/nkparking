// 인증 체크
function checkAuth() {
    const currentUser = sessionStorage.getItem('currentUser');
    const userType = sessionStorage.getItem('userType');

    if (!currentUser || userType !== 'employee') {
        alert('직원 권한이 필요합니다.');
        window.location.href = 'index.html';
        return null;
    }

    return JSON.parse(currentUser);
}

// 로그아웃
function logout() {
    sessionStorage.clear();
    window.location.href = 'index.html';
}

// 탭 전환
function switchTab(tabName) {
    // 모든 탭과 컨텐츠 비활성화
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    // 선택된 탭 활성화
    event.target.classList.add('active');
    document.getElementById(tabName).classList.add('active');

    // 해당 탭의 데이터 로드
    if (tabName === 'myApplications') loadMyApplications();
    if (tabName === 'announcements') loadAnnouncements();
}

// 연도 옵션 생성
function populateYears() {
    const currentYear = new Date().getFullYear();
    const yearSelects = ['year', 'editYear'];
    
    yearSelects.forEach(selectId => {
        const select = document.getElementById(selectId);
        if (select) {
            select.innerHTML = '<option value="">선택하세요</option>';
            for (let year = currentYear - 1; year <= currentYear + 2; year++) {
                const option = document.createElement('option');
                option.value = year;
                option.textContent = year + '년';
                select.appendChild(option);
            }
        }
    });
}

// 주차 신청
document.getElementById('applicationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    
    const year = document.getElementById('year').value;
    const quarter = document.getElementById('quarter').value;
    const parkingType = document.getElementById('parkingType').value;
    const carNumber = document.getElementById('carNumber').value;
    
    // 중복 신청 체크 (같은 분기, 같은 유형)
    const duplicate = applications.find(app => 
        app.employeeId === currentUser.id &&
        app.year == year &&
        app.quarter == quarter &&
        app.parkingType === parkingType &&
        app.status !== '반려'
    );
    
    if (duplicate) {
        alert('같은 분기에 같은 유형으로 이미 신청하셨습니다.');
        return;
    }
    
    // 새 신청 생성
    const newApplication = {
        id: Date.now().toString(),
        employeeId: currentUser.id,
        year: parseInt(year),
        quarter: parseInt(quarter),
        parkingType: parkingType,
        carNumber: carNumber,
        status: '대기중',
        createdAt: new Date().toISOString()
    };
    
    applications.push(newApplication);
    localStorage.setItem('parkingApplications', JSON.stringify(applications));
    
    alert('신청이 완료되었습니다.');
    this.reset();
    
    // 내 신청 내역 탭으로 이동
    switchTab('myApplications');
    document.querySelector('.tab[onclick*="myApplications"]').click();
});

// 내 신청 내역 조회
function loadMyApplications() {
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const tbody = document.getElementById('myApplicationsBody');
    
    tbody.innerHTML = '';
    
    const myApplications = applications.filter(app => app.employeeId === currentUser.id)
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    if (myApplications.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">신청 내역이 없습니다.</td></tr>';
        return;
    }
    
    myApplications.forEach(app => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(app.createdAt).toLocaleDateString()}</td>
            <td>${app.year}</td>
            <td>${app.quarter}분기</td>
            <td>${app.parkingType}</td>
            <td>${app.carNumber}</td>
            <td><span class="status-badge status-${getStatusClass(app.status)}">${app.status}</span></td>
            <td>
                ${app.status === '대기중' ? `
                    <button class="btn btn-small" onclick="editApplication('${app.id}')">수정</button>
                    <button class="btn btn-danger btn-small" onclick="deleteApplication('${app.id}')">삭제</button>
                ` : '-'}
            </td>
        `;
        tbody.appendChild(row);
    });
}

function getStatusClass(status) {
    if (status === '대기중') return 'pending';
    if (status === '승인') return 'approved';
    if (status === '반려') return 'rejected';
    return 'pending';
}

// 신청 수정
function editApplication(id) {
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const app = applications.find(a => a.id === id);
    
    if (!app) return;
    
    document.getElementById('editId').value = app.id;
    document.getElementById('editYear').value = app.year;
    document.getElementById('editQuarter').value = app.quarter;
    document.getElementById('editParkingType').value = app.parkingType;
    document.getElementById('editCarNumber').value = app.carNumber;
    
    document.getElementById('editModal').classList.add('show');
}

function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}

document.getElementById('editForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    
    const id = document.getElementById('editId').value;
    const year = document.getElementById('editYear').value;
    const quarter = document.getElementById('editQuarter').value;
    const parkingType = document.getElementById('editParkingType').value;
    const carNumber = document.getElementById('editCarNumber').value;
    
    // 중복 체크 (자신 제외)
    const duplicate = applications.find(app => 
        app.id !== id &&
        app.employeeId === currentUser.id &&
        app.year == year &&
        app.quarter == quarter &&
        app.parkingType === parkingType &&
        app.status !== '반려'
    );
    
    if (duplicate) {
        alert('같은 분기에 같은 유형으로 이미 신청하셨습니다.');
        return;
    }
    
    // 신청 수정
    const app = applications.find(a => a.id === id);
    if (app) {
        app.year = parseInt(year);
        app.quarter = parseInt(quarter);
        app.parkingType = parkingType;
        app.carNumber = carNumber;
        
        localStorage.setItem('parkingApplications', JSON.stringify(applications));
        
        closeEditModal();
        loadMyApplications();
        alert('수정되었습니다.');
    }
});

// 신청 삭제
function deleteApplication(id) {
    if (!confirm('신청을 삭제하시겠습니까?')) return;
    
    const applications = JSON.parse(localStorage.getItem('parkingApplications') || '[]');
    const filtered = applications.filter(a => a.id !== id);
    
    localStorage.setItem('parkingApplications', JSON.stringify(filtered));
    loadMyApplications();
    alert('삭제되었습니다.');
}

// 공지사항 조회
function loadAnnouncements() {
    const announcements = JSON.parse(localStorage.getItem('announcements') || '[]');
    const container = document.getElementById('announcementsList');
    
    container.innerHTML = '';
    
    if (announcements.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 20px; color: #666;">등록된 공지사항이 없습니다.</p>';
        return;
    }
    
    announcements.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).forEach(ann => {
        const div = document.createElement('div');
        div.className = 'announcement-item';
        div.innerHTML = `
            <div class="announcement-title">${ann.title}</div>
            <div class="announcement-meta">${ann.author} · ${new Date(ann.createdAt).toLocaleDateString()}</div>
            <div class="announcement-content" id="content-${ann.id}">${ann.content.replace(/\n/g, '<br>')}</div>
        `;
        
        div.addEventListener('click', function() {
            const content = document.getElementById('content-' + ann.id);
            content.classList.toggle('show');
        });
        
        container.appendChild(div);
    });
}

// 초기화
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = checkAuth();
    if (currentUser) {
        document.getElementById('userName').textContent = currentUser.name + ' 님 (' + currentUser.department + ')';
        populateYears();
        loadAnnouncements();
    }
});