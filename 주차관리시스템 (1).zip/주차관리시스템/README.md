# 🚗 주차 관리 시스템

분기별 주차 신청 및 관리를 위한 웹 기반 시스템입니다.

## 📋 주요 기능

### 관리자 기능
- ✅ 로그인 및 세션 관리
- ✅ 직원 관리 (추가, 삭제)
- ✅ Excel 파일로 직원 일괄 등록
- ✅ 주차 신청 승인/반려 처리
- ✅ 빠른 승인 기능 (대기중인 모든 신청 일괄 승인)
- ✅ 공지사항 관리
- ✅ 분기별 통계 조회
- ✅ 월별 일일 결제 추적 (미당첨 SUV)
- ✅ CSV 데이터 다운로드

### 직원 기능
- ✅ 로그인 및 세션 관리
- ✅ 주차 신청 (연도/분기/유형 선택)
- ✅ 내 신청 내역 조회
- ✅ 신청 수정/삭제 (대기중 상태만)
- ✅ 공지사항 확인

### 주차 유형
1. **선착순 일일권** - 일일 단위 선착순 주차권
2. **월정기권** - 월 단위 정기 주차권
3. **미당첨 SUV** - SUV 차량 미당첨자 대상

## 🎯 주요 특징

### 중복 신청 제어
- 같은 분기에 같은 유형은 중복 신청 불가
- 다른 유형은 같은 분기에도 신청 가능
- 반려된 신청은 재신청 가능

### 데이터 보존
- 연도/분기/유형 변경 시에도 기존 데이터 유지
- 로그인 세션 유지
- LocalStorage 기반 데이터 저장

### 통계 기능
- 분기별 신청 현황 통계
- 유형별/부서별 통계
- 승인율 계산
- 월별 일일 결제 추적 (미당첨 SUV 전용)

## 🛠️ 기술 스택

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Data Storage**: LocalStorage (Browser)
- **Excel Processing**: SheetJS (xlsx)
- **Design**: Gradient UI with responsive layout

## 📁 파일 구조

```
parking-management/
├── index.html              # 로그인 페이지
├── admin.html              # 관리자 페이지
├── employee.html           # 직원 페이지
├── statistics.html         # 상세 통계 페이지
├── js/
│   ├── admin.js           # 관리자 로직
│   ├── employee.js        # 직원 로직
│   └── statistics.js      # 통계 로직
└── README.md              # 프로젝트 문서
```

## 🚀 시작하기

1. **프로젝트 실행**
   - index.html 파일을 웹 브라우저로 열기
   - 또는 로컬 웹 서버 실행

2. **기본 계정**
   - 관리자: `admin` / `admin123`
   - 직원1: `emp001` / `emp001`
   - 직원2: `emp002` / `emp002`

3. **Excel 파일 형식 (직원 일괄 등록)**
   ```
   아이디 | 비밀번호 | 이름 | 부서
   emp003 | pass123  | 홍길동 | 개발팀
   emp004 | pass456  | 김철수 | 영업팀
   ```

## 💡 사용 가이드

### 관리자
1. 관리자 계정으로 로그인
2. 직원 관리 탭에서 직원 추가 또는 Excel 일괄 등록
3. 주차 신청 관리 탭에서 신청 승인/반려
4. 통계 탭에서 분기별 현황 확인
5. CSV 다운로드로 데이터 백업

### 직원
1. 직원 계정으로 로그인
2. 주차 신청 탭에서 연도/분기/유형 선택 후 신청
3. 내 신청 내역에서 상태 확인
4. 대기중 상태일 때 수정/삭제 가능
5. 공지사항 확인

## 📊 데이터 구조

### employees (직원)
```javascript
{
  id: string,           // 아이디
  password: string,     // 비밀번호
  name: string,         // 이름
  department: string,   // 부서
  isAdmin: boolean      // 관리자 여부
}
```

### parkingApplications (주차 신청)
```javascript
{
  id: string,           // 신청 ID
  employeeId: string,   // 직원 ID
  year: number,         // 연도
  quarter: number,      // 분기 (1-4)
  parkingType: string,  // 주차 유형
  carNumber: string,    // 차량번호
  status: string,       // 상태 (대기중/승인/반려)
  createdAt: string,    // 신청일
  approvedAt: string?,  // 승인일
  rejectedAt: string?   // 반려일
}
```

### announcements (공지사항)
```javascript
{
  id: string,           // 공지 ID
  title: string,        // 제목
  content: string,      // 내용
  author: string,       // 작성자
  createdAt: string     // 작성일
}
```

## 🔧 주요 함수

### 공통
- `checkAuth()` - 인증 확인
- `logout()` - 로그아웃
- `switchTab()` - 탭 전환

### 관리자
- `loadApplications()` - 신청 목록 로드
- `approveApplication()` - 신청 승인
- `rejectApplication()` - 신청 반려
- `quickApprove()` - 빠른 승인
- `handleExcelUpload()` - Excel 일괄 등록
- `exportApplicationsCSV()` - CSV 다운로드

### 직원
- `loadMyApplications()` - 내 신청 내역 로드
- `editApplication()` - 신청 수정
- `deleteApplication()` - 신청 삭제

### 통계
- `loadStatistics()` - 통계 데이터 로드
- `loadMonthlyTracking()` - 월별 일일 추적
- `exportStatisticsCSV()` - 통계 CSV 다운로드

## ⚠️ 주의사항

1. **데이터 백업**
   - LocalStorage 사용으로 브라우저 데이터 삭제 시 모든 정보 손실
   - 정기적으로 CSV 다운로드하여 백업 권장

2. **브라우저 호환성**
   - 최신 브라우저(Chrome, Firefox, Edge, Safari) 사용 권장
   - LocalStorage 지원 필수

3. **보안**
   - 현재 버전은 데모용으로 실제 운영 시 서버 기반 인증 필요
   - 비밀번호 암호화 미적용 (실제 운영 시 필수)

## 📈 향후 개선 사항

- [ ] 서버 기반 데이터베이스 연동
- [ ] 비밀번호 암호화
- [ ] 이메일/SMS 알림 기능
- [ ] 주차 공간 실시간 현황
- [ ] 모바일 앱 지원
- [ ] 결제 시스템 연동

## 📝 버전 정보

- **Version**: 1.0.0
- **Last Updated**: 2025-10-30
- **Status**: Production Ready

## 👨‍💻 개발자

개발 및 문의: Genspark AI Assistant

---

© 2025 주차 관리 시스템. All rights reserved.